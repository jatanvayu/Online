package com.techm.models;

import java.util.Date;

public class Bill 
{
	private String userName;
	private int planId;
	private Date dop;
	private String status;
	private String planType;
	
	public Bill()
	{
		
	}
	
	public Bill(String userName, int planId, Date dop, String status,
			String planType) 
	{
		super();
		this.userName = userName;
		this.planId = planId;
		this.dop = dop;
		this.status = status;
		this.planType = planType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public Date getDop() {
		return dop;
	}

	public void setDop(Date dop) {
		this.dop = dop;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPlanType() {
		return planType;
	}

	public void setPlanType(String planType) {
		this.planType = planType;
	}

	@Override
	public String toString() 
	{
		return "Bill [userName=" + userName + ", planId=" + planId + ", dop="
				+ dop + ", status=" + status + ", planType=" + planType + "]";
	}
	
	
	

	
}
