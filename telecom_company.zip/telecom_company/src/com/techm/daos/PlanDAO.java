package com.techm.daos;

import java.sql.Connection;
import java.util.ArrayList;

import com.techm.models.Customer;
import com.techm.models.Plan;

public interface PlanDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public ArrayList<Plan> getAllPlans();
	public boolean addPlan(Plan plan);
	public boolean updatePlanCharges(Plan plan);
	public boolean updatePlanDetails(Plan plan);
	public boolean updatePlanValidity(Plan plan);
	public boolean removePlan(Plan plan);
	public Plan getPlan(int planId);
	public boolean updatePlan(Plan plan);
	
	
}
