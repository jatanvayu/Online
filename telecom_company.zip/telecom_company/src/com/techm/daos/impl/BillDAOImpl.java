package com.techm.daos.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.techm.daos.BillDAO;
import com.techm.daos.PlanDAO;
import com.techm.models.Bill;
import com.techm.models.Customer;
import com.techm.models.Plan;

public class BillDAOImpl implements BillDAO {
	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	public BillDAOImpl()
	{
		try 
		{
			Class.forName(driverClass);
			System.out.println("Driver Loaded!");
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	@Override
	public Connection getConnection() 
	{
		try 
		{
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("connection to DB established!");
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public void closeConnection() 
	{
		if(con!=null)
		{
			try 
			{
				con.close();
				System.out.println("Connection to DB closed!");
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

	@Override
	public void addPlans(Customer customer, String[] options) 
	{
		PlanDAO planDao=new PlanDAOImpl();
		for(String s:options)
		{
		String SQL="insert into bill_tbl values(?,?,?,?,?)";
		
		getConnection();
			try 
			{	
				System.out.println(s);
				int c=Integer.parseInt(s);
				System.out.println(planDao.getPlan(c).getPlanType()+"value");
				
				Date date=new Date();
				String d=date.toString();
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUserName());
				ps.setInt(2, c);
				ps.setString(3, d);
				ps.setString(4, "valid");
				ps.setString(5, planDao.getPlan(c).getPlanType());
				
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					System.out.println("Plan Added!");
				}
				else
				{
					System.out.println("Plan not Added!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
		}
		
	}

	@Override
	public ArrayList<Bill> getPrepaidPlans(Customer customer) 
	{
		String SQL="select * from bill_tbl where username=? and plantype='prepaid'";
		ArrayList<Bill> prepaidList=new ArrayList<Bill>();
		Bill bill=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, customer.getUserName());
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				bill=new Bill();
				
				bill.setUserName(rs.getString("username"));
				bill.setPlanId(rs.getInt("planid"));
				bill.setDop(rs.getDate("dop"));
				bill.setStatus(rs.getString("status"));
				bill.setPlanType(rs.getString("plantype"));
				
				
				prepaidList.add(bill);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return prepaidList;
	}

	@Override
	public ArrayList<Bill> getPostpaidPlans(Customer customer) 
	{
		String SQL="select * from bill_tbl where username=? and plantype='postpaid'";
		ArrayList<Bill> postpaidList=new ArrayList<Bill>();
		Bill bill=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, customer.getUserName());
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				bill=new Bill();
				
				bill.setUserName(rs.getString("username"));
				bill.setPlanId(rs.getInt("planid"));
				bill.setDop(rs.getDate("dop"));
				bill.setStatus(rs.getString("status"));
				bill.setPlanType(rs.getString("plantype"));
				
				
				postpaidList.add(bill);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return postpaidList;
	}

	@Override
	public void rechargePrepaid(Customer customer,String[] options)
	{
		
		for(String s:options)
		{
			String SQL="update bill_tbl set status='valid' where username=? and planid=?";
			getConnection();
			
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUserName());
				ps.setInt(2, Integer.parseInt(s));
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					System.out.println("Plan Recharged!");
				}
				else
				{
					System.out.println("Plan not Recharged!");
				}
			}	
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
			
			
		}
		
	}

	@Override
	public void rechargePostpaid(Customer customer,String[] options)
	{
		
		for(String s:options)
		{
			String SQL="update bill_tbl set status='valid' where username=? and planid=?";
			getConnection();
			
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUserName());
				ps.setInt(2, Integer.parseInt(s));
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					System.out.println("Paid!");
				}
				else
				{
					System.out.println("Not Paid!");
				}
			}	
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
		}
		
	}
	@Override
	public ArrayList<Bill> getPlansBought(Customer customer) 
	{
		String SQL="select * from bill_tbl where username=?";
		ArrayList<Bill> billList=new ArrayList<Bill>();
		Bill bill=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, customer.getUserName());
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				bill=new Bill();
				
				bill.setUserName(rs.getString("username"));
				bill.setPlanId(rs.getInt("planid"));
				bill.setDop(rs.getDate("dop"));
				bill.setStatus(rs.getString("status"));
				bill.setPlanType(rs.getString("plantype"));
				
				
				billList.add(bill);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return billList;
	}
	
	@Override
	public ArrayList<Plan> getPlansToBuy(Customer customer)
	{
		ArrayList<Plan> planList=new ArrayList<Plan>();
		Plan plan=null;
		
		String SQL="select planid from plan_tbl where planid not in(select planid from bill_tbl where username=?)";
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, customer.getUserName());
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				plan=new Plan();
				plan.setPlanId(rs.getInt("planid"));
				planList.add(plan);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return planList;
	}

}
