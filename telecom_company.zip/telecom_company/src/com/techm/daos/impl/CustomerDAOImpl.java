package com.techm.daos.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.daos.CustomerDAO;
import com.techm.models.Customer;

public class CustomerDAOImpl implements CustomerDAO 
{
	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	public CustomerDAOImpl()
	{
		try 
		{
			Class.forName(driverClass);
			System.out.println("Driver Loaded!");
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	
	
	@Override
	public Connection getConnection() 
	{
		
	try 
	{
		con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
		System.out.println("connection to DB established!");
	} 
	catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con;
	
	}

	@Override
	public void closeConnection() 
	{
	
	if(con!=null)
	{
		try 
		{
			con.close();
			System.out.println("Connection to DB closed!");
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	}

	@Override
	public boolean addCustomer(Customer customer)
	{
		String SQL="insert into customer_tbl values(?,?,?,?,?,?,?)";
		boolean isAdded=false;
	
		if(customer.getUserName()!=null && customer.getPassword()!=null && customer.getFirstName()!=null && customer.getLastName()!=null && customer.getCity()!=null && customer.getEmail()!=null && customer.getCellNo()!=null)
		{
			
			System.out.println("all entries made!");
			getConnection();
			
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setString(1, customer.getUserName());
				ps.setString(2, customer.getPassword());
				ps.setString(3, customer.getFirstName());
				ps.setString(4, customer.getLastName());
				ps.setString(5, customer.getCity());
				ps.setString(6, customer.getEmail());
				ps.setString(7, customer.getCellNo());
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Customer Added!");
				}
				else
				{
					System.out.println("Customer not Added!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
		
		}
		else
		{
			System.out.println("Entries left!");
			isAdded=false;
			
		}
			
		
		return isAdded;
	}

	@Override
	public boolean validateCustomer(Customer customer) 
	{
		String SQL="select * from customer_tbl where username=? and password=?";
		boolean isValid=false;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, customer.getUserName());
			ps.setString(2, customer.getPassword());
			ResultSet rs=ps.executeQuery();
			//validation 
			if(rs.next())
			{
				isValid=true;
			}
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection(); 
		}
		
		return isValid;
	}

}
