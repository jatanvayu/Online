package com.techm.daos.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.techm.daos.FaqDAO;
import com.techm.models.Faq;


public class FaqDAOImpl implements FaqDAO 
{

	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	public FaqDAOImpl()
	{
		try 
		{
			Class.forName(driverClass);
			System.out.println("Driver Loaded!");
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	@Override
	public Connection getConnection() 
	{
		try 
		{
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("connection to DB established!");
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public void closeConnection() 
	{
		if(con!=null)
		{
			try 
			{
				con.close();
				System.out.println("Connection to DB closed!");
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

	@Override
	public ArrayList<Faq> getAllFaq() 
	{
		String SQL="select * from faq_tbl";
		ArrayList<Faq> faqList=new ArrayList<Faq>();
		Faq faq=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				faq=new Faq();
				
				faq.setFaqId(rs.getInt("faqid"));
				faq.setQuestion(rs.getString("question"));
				
				
				faqList.add(faq);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return faqList;
	}

	@Override
	public boolean updateFaq(Faq faq) 
	{
		String SQL="update faq_tbl set question=? where faqid=?";
		getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, faq.getQuestion());
			ps.setInt(2, faq.getFaqId());
			
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Faq Updated!");
			}
			else
			{
				System.out.println("Faq not Updated!");
			}
		}	
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		
		return isUpdated;
	}

}
