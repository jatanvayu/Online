package com.techm.daos.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.techm.daos.BillDAO;
import com.techm.daos.PlanDAO;
import com.techm.models.Customer;
import com.techm.models.Plan;


public class PlanDAOImpl implements PlanDAO 
{
	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	private BillDAO billDao;
	public PlanDAOImpl()
	{
		try 
		{
			Class.forName(driverClass);
			System.out.println("Driver Loaded!");
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	@Override
	public Connection getConnection() 
	{
		try 
		{
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("connection to DB established!");
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public void closeConnection() 
	{
		if(con!=null)
		{
			try 
			{
				con.close();
				System.out.println("Connection to DB closed!");
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public ArrayList<Plan> getAllPlans() {
		String SQL="select * from plan_tbl";
		ArrayList<Plan> planList=new ArrayList<Plan>();
		Plan plan=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			while(rs.next())
			{
				plan=new Plan();
				
				plan.setPlanId(rs.getInt("planid"));
				plan.setPlanType(rs.getString("plantype"));
				plan.setPlanName(rs.getString("planname"));
				plan.setCharges(rs.getDouble("charges"));
				plan.setDetails(rs.getString("details"));
				plan.setValidity(rs.getInt("validity"));
				
				planList.add(plan);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return planList;
	}

	@Override
	public boolean addPlan(Plan plan) 
	{
		String SQL="insert into plan_tbl values(?,?,?,?,?,?)";
		boolean isAdded=false;
		getConnection();
			try 
			{
				PreparedStatement ps=con.prepareStatement(SQL);
				ps.clearParameters();
				ps.setInt(1, plan.getPlanId());
				ps.setString(2, plan.getPlanType());
				ps.setString(3, plan.getPlanName());
				ps.setDouble(4, plan.getCharges());
				ps.setString(5, plan.getDetails());
				ps.setInt(6, plan.getValidity());
				
				int cnt=ps.executeUpdate();
				if(cnt==1)
				{
					isAdded=true;
					System.out.println("Plan Added!");
				}
				else
				{
					System.out.println("Plan not Added!");
				}
			} 
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				closeConnection();
			}
		
		return isAdded;
	}

	@Override
	public boolean updatePlanCharges(Plan plan) 
	{
		String SQL="update plan_tbl set charges=? where planid=?";
		getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setDouble(1, plan.getCharges());
			ps.setInt(2,plan.getPlanId());
			
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		
		return isUpdated;
	}

	@Override
	public boolean updatePlanDetails(Plan plan) 
	{
		String SQL="update plan_tbl set details=? where planid=?";
		getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, plan.getDetails());
			ps.setInt(2,plan.getPlanId());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		
		return isUpdated;
	}

	@Override
	public boolean updatePlanValidity(Plan plan) 
	{
		String SQL="update plan_tbl set validity=? where planid=?";
		getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, plan.getValidity());
			ps.setInt(2,plan.getPlanId());
			
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		
		return isUpdated;
	}

		
	@Override
	public boolean removePlan(Plan plan) 
	{
		String SQL="delete from plan_tbl where planid=?";
		boolean isRemoved=false;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, plan.getPlanId());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isRemoved=true;
				System.out.println("Plan Removed!");
			}
			else
			{
				System.out.println("Plan not removed!");
			}
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return isRemoved;
	}

	@Override
	public Plan getPlan(int planId) 
	{
		String SQL="select * from plan_tbl where planid=?";
		
		Plan plan=null;
		getConnection();
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, planId);
			ResultSet rs=ps.executeQuery();
			//Since multiple records are expected we use while
			if(rs.next())
			{
				plan=new Plan();
				
				plan.setPlanId(Integer.parseInt(rs.getString("planid")));
				plan.setPlanType(rs.getString("plantype"));
				plan.setPlanName(rs.getString("planname"));
				plan.setCharges(Double.parseDouble(rs.getString("charges")));
				plan.setDetails(rs.getString("details"));
				plan.setValidity(Integer.parseInt(rs.getString("validity")));
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		return plan;
	}

	@Override
	public boolean updatePlan(Plan plan) 
	{
		String SQL="update plan_tbl set charges=?,details=?,validity=? where planid=?";
		getConnection();
		boolean isUpdated=false;
		try 
		{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setDouble(1,plan.getCharges());
			ps.setString(2, plan.getDetails());
			ps.setInt(3, plan.getValidity());
			ps.setInt(4, plan.getPlanId());
			
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("Plan Updated!");
			}
			else
			{
				System.out.println("Plan not Updated!");
			}
		}	
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			closeConnection();
		}
		
		return isUpdated;
	}

	
	
	
}
