package com.techm.daos;

import java.sql.Connection;

public interface StoreLocDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public String getAddresses(String city);

}
