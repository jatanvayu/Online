package com.techm.daos;

import java.sql.Connection;
import java.util.ArrayList;

import com.techm.models.Customer;
import com.techm.models.WriteToUs;

public interface WriteToUsDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public boolean setQuery(Customer c,String query);
	public ArrayList<WriteToUs> getAllQueries();
	public boolean submitAnswer(String userName,String answer);
	public ArrayList<WriteToUs> getAnsweredQueries();

}
