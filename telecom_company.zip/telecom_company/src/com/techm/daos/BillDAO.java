package com.techm.daos;

import java.sql.Connection;
import java.util.ArrayList;

import com.techm.models.Bill;
import com.techm.models.Customer;
import com.techm.models.Plan;


public interface BillDAO 
{
	public Connection getConnection();
	public void closeConnection();
	public void addPlans(Customer customer,String options[]);
	public ArrayList<Bill> getPrepaidPlans(Customer customer);
	public ArrayList<Bill> getPostpaidPlans(Customer customer);
	public void rechargePrepaid(Customer customer,String options[]);
	public void rechargePostpaid(Customer customer,String options[]);
	public ArrayList<Plan> getPlansToBuy(Customer customer);
	public ArrayList<Bill> getPlansBought(Customer customer);
}
