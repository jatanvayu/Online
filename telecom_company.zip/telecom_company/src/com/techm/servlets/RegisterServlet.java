package com.techm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.daos.CustomerDAO;
import com.techm.daos.impl.CustomerDAOImpl;
import com.techm.models.Customer;



public class RegisterServlet extends HttpServlet 
{
	private CustomerDAO customerDao;
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("RegisterServlet Init invoked!");
		customerDao=new CustomerDAOImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
	System.out.println("RegisterServlet doGet invoked!");
	
	String userName=request.getParameter("userName");
	String password=request.getParameter("password");
	
	String firstName=request.getParameter("firstName");
	String lastName=request.getParameter("lastName");
	
	String city=request.getParameter("city");
	String email=request.getParameter("email");
	String cellNo=request.getParameter("cellNo");
	// TODO Auto-generated method stub
	
	Customer customer=new Customer(userName, password, firstName, lastName, city, email, cellNo);
	boolean isAdded=customerDao.addCustomer(customer);	
	if(isAdded==true)
	{	
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<center><h2>Successfully Registered!</h2>");
	

		
	RequestDispatcher rd=request.getRequestDispatcher("/signup.jsp");
	rd.include(request,response );
	}
	else
	{
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<center><h2>Error during registration!</h2>");
	
		out.println("<h2>Please try again!</h2></center>");
		
		RequestDispatcher rd=request.getRequestDispatcher("/signup.jsp");
		rd.include(request,response );
		
	}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
