package com.techm.servlets;

import java.util.ArrayList;

import com.techm.daos.BillDAO;
import com.techm.daos.FaqDAO;
import com.techm.daos.impl.BillDAOImpl;
import com.techm.daos.impl.FaqDAOImpl;
import com.techm.models.Customer;
import com.techm.models.Faq;
import com.techm.models.Plan;





public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Customer customer=new Customer();
		customer.setUserName("zeus");
		BillDAO billDao=new BillDAOImpl();
		ArrayList<Plan> planList=billDao.getPlansToBuy(customer);
		if(planList.isEmpty())
		{
			System.out.println("Null");
		}
		for(Plan p:planList)
		{
			System.out.println(p);
		}

	}

}
