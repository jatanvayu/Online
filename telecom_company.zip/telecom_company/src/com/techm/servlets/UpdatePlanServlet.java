package com.techm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.PlanDAO;
import com.techm.daos.impl.PlanDAOImpl;
import com.techm.models.Plan;


public class UpdatePlanServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	private PlanDAO planDao;

	public void init(ServletConfig config) throws ServletException {
		planDao=new	PlanDAOImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		
		
		Plan planToUpdate=new Plan();
		planToUpdate.setPlanId(Integer.parseInt(request.getParameter("id")));
		planToUpdate.setCharges(Double.parseDouble(request.getParameter("charges")));
		planToUpdate.setDetails(request.getParameter("details"));
		planToUpdate.setValidity(Integer.parseInt(request.getParameter("validity")));
		
		planDao.updatePlan(planToUpdate);
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<center><h2>Plan Updated!</h2>");

		
		RequestDispatcher rd=request.getRequestDispatcher("/updateplanshome.jsp");
		rd.include(request,response );
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
