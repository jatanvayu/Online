package com.techm.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.CustomerDAO;
import com.techm.daos.impl.CustomerDAOImpl;
import com.techm.models.Customer;





public class LoginServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private CustomerDAO customerDao;

	public void init(ServletConfig config) throws ServletException
	{
		System.out.println("Login Servlet Init invoked!");
		customerDao=new CustomerDAOImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		session.setMaxInactiveInterval(1000);
		
		System.out.println("Login Servlet doGet invoked!");

		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		Customer customer=new Customer();
		customer.setUserName(userName);
		customer.setPassword(password);
		boolean isValid=customerDao.validateCustomer(customer);
		
		if(isValid==true)
		{	
			session.setAttribute("sessionCustomer",customer);
			System.out.println("Customer logged in!");
			RequestDispatcher rd=request.getRequestDispatcher("/customerhome.jsp");
			rd.forward(request, response); //the output of the servlet takes you to a new window!
			//rd.include(request, response);//Output of the servlet is added to the same window!
		}
		else
		{
			if(userName.equals("admin") && password.equals("admin"))
			{
				session.setAttribute("sessionAdmin","admin");
				System.out.println("Admin logged in!");
				RequestDispatcher rd=request.getRequestDispatcher("/adminhome.jsp");
				rd.forward(request, response);
			}
			else
			{
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			out.println("<center><h2>Error during login!</h2>");
		
			out.println("<h2>Please try again!</h2></center>");
			
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			rd.include(request,response );
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
