package com.techm.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.daos.BillDAO;
import com.techm.daos.PlanDAO;
import com.techm.daos.impl.BillDAOImpl;
import com.techm.daos.impl.PlanDAOImpl;
import com.techm.models.Customer;
import com.techm.models.Plan;



public class GetPlansToBuyServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private BillDAO billDao;
	private PlanDAO planDao;

	public void init(ServletConfig config) throws ServletException 
	{
		// TODO Auto-generated method stub
		billDao=new BillDAOImpl();
		planDao=new PlanDAOImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		Customer sessionCustomer=(Customer)session.getAttribute("sessionCustomer");
		Plan plan=null;
		
		System.out.println("GetPlansToBuyServlet doGet Invoked!");
		
		ArrayList<Plan> planList=billDao.getPlansToBuy(sessionCustomer);
		if(planList.isEmpty())
		{
			System.out.println("no values fetched");
		}
		ArrayList<Plan> plansToBuy=new ArrayList<Plan>();
		for(Plan p:planList)
		{	
			plan=new Plan();
			plan=planDao.getPlan(p.getPlanId());
			plansToBuy.add(plan);
		}
		session.setAttribute("plansToBuy", plansToBuy);
		
		RequestDispatcher rd=request.getRequestDispatcher("/buyplans.jsp");
		rd.forward(request,response );
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
